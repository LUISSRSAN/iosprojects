
protocol CanFly{
    func fly()
}

class Bird {
    
    var isFemale = true
    func layEgg(){
        if  isFemale{
            print("the bird makes a new bird in a shell")
        }
    }
    func fly(){
        print("flaps its wings and lifts off into the sky")
    }
    
}
class Eagle: Bird, CanFly {
    
    func soar(){
        print("eagle glides in the air using air currents")
    }
}

class Penguin:Bird{
    func swim(){
        print("penguin paddles through the water")
    }
}


struct FlyingMuseuem{
    func  flyingDemo(flyingObject : CanFly){
        flyingObject.fly()
    }
}

struct Airplane: CanFly{
    func fly(){
        print("airplane liftss off ")
    }
}
let myEagle = Eagle()
myEagle.fly()
myEagle.layEgg()
myEagle.soar()

let myPenguin = Penguin()
myPenguin.fly()
myPenguin.layEgg()
myPenguin.swim()

let museum = FlyingMuseuem(flyingObject:myEagle)

let airplane = Airplane()
